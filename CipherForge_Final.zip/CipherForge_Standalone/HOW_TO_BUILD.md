# ⬡ CipherForge v2.1 — Getting Your EXE
**Made by Krut Vyas**

---

## How to build the EXE (choose one method)

### ✅ Method 1 — Double-click (easiest)
1. Extract this folder anywhere on your PC
2. Double-click **`COMPILE_TO_EXE.bat`**
3. The script auto-detects your compiler and builds `dist\CipherForge.exe`
4. The `dist\` folder opens automatically when done

> If you don't have .NET SDK, the script opens the download page for you.

---

### ✅ Method 2 — Visual Studio 2022 (recommended for projects)
1. Open Visual Studio 2022
2. Create a new **Windows Forms App (.NET 6)** project
3. Replace the generated `Program.cs` with the contents of `CipherForge.cs`
4. Press **F5** to run, or **Ctrl+Shift+B** to build
5. EXE is in `bin\Release\net6.0-windows\`

---

### ✅ Method 3 — Command Line (.NET 6 SDK)
```bat
dotnet new winforms -n CF
copy CipherForge.cs CF\Program.cs
cd CF
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o ..\dist
```

---

## What CipherForge does

| Feature | Detail |
|---|---|
| Text encryption | Encrypt / decrypt any text → Base64 |
| File encryption | Encrypt / decrypt any file (all formats) |
| Algorithms | **AES-256**, DES, TripleDES, RC2 |
| Key generation | Cryptographically secure random keys |
| UI | Cyberpunk dark theme, hex-grid animation |
| Splash screen | Animated loading screen |
| Author | Krut Vyas (shown in header, splash, footer) |

---

*CipherForge v2.1 · © 2025 Krut Vyas*
