@echo off
title CipherForge — Windows Compiler
color 0B
echo.
echo  =====================================================
echo    CIPHERFORGE v2.1  —  Compiler
echo    Made by Krut Vyas
echo  =====================================================
echo.

REM ── Try .NET 6 SDK first (best option) ──────────────────────────────────
where dotnet >nul 2>&1
if %errorlevel% equ 0 (
    echo  [OK] .NET SDK found. Building with dotnet...
    echo.
    dotnet new winforms -n CipherForgeDotNet --force >nul 2>&1
    copy /Y CipherForge.cs CipherForgeDotNet\Program.cs >nul
    cd CipherForgeDotNet
    dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o ..\dist >nul
    cd ..
    rmdir /s /q CipherForgeDotNet >nul 2>&1
    goto :done
)

REM ── Try built-in .NET Framework csc.exe ─────────────────────────────────
echo  [INFO] .NET SDK not found. Trying built-in Windows compiler...
echo.

set CSC=
for %%v in (4.0 3.5 2.0) do (
    if exist "%WINDIR%\Microsoft.NET\Framework64\v%%v\csc.exe" (
        set "CSC=%WINDIR%\Microsoft.NET\Framework64\v%%v\csc.exe"
        goto :found
    )
    if exist "%WINDIR%\Microsoft.NET\Framework\v%%v\csc.exe" (
        set "CSC=%WINDIR%\Microsoft.NET\Framework\v%%v\csc.exe"
        goto :found
    )
)

echo  [ERROR] No compiler found on this machine.
echo.
echo  Please install ONE of the following:
echo    Option A (Recommended): .NET 6 SDK
echo      https://dotnet.microsoft.com/download/dotnet/6.0
echo.
echo    Option B: Visual Studio 2022 (Community is free)
echo      https://visualstudio.microsoft.com/downloads/
echo.
pause
start https://dotnet.microsoft.com/download/dotnet/6.0
exit /b 1

:found
echo  [OK] Compiler found: %CSC%
echo.

if not exist dist mkdir dist

"%CSC%" /target:winexe ^
        /out:dist\CipherForge.exe ^
        /r:System.dll ^
        /r:System.Core.dll ^
        /r:System.Drawing.dll ^
        /r:System.Security.dll ^
        /r:System.Windows.Forms.dll ^
        /optimize+ ^
        /platform:x86 ^
        CipherForge.cs

if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Compilation failed. See output above.
    pause
    exit /b 1
)

:done
echo.
if exist dist\CipherForge.exe (
    echo  =====================================================
    echo   BUILD SUCCESSFUL!
    echo   dist\CipherForge.exe  is ready to run.
    echo  =====================================================
    echo.
    explorer dist
) else (
    echo  [WARN] dist\CipherForge.exe not found — check errors above.
)
pause
