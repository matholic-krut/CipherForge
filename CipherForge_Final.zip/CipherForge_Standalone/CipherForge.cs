// CipherForge v2.1 — Advanced Encryption Workstation
// Made by Krut Vyas
// Compile: csc.exe /target:winexe /out:CipherForge.exe /r:System.Windows.Forms.dll /r:System.Drawing.dll CipherForge.cs

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

// ════════════════════════════════════════════════════════════════════════════
//  ENTRY POINT
// ════════════════════════════════════════════════════════════════════════════
static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new SplashScreen());
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  SPLASH SCREEN
// ════════════════════════════════════════════════════════════════════════════
class SplashScreen : Form
{
    static readonly Color BG      = Color.FromArgb(10, 13, 20);
    static readonly Color CYAN    = Color.FromArgb(0, 212, 255);
    static readonly Color MAGENTA = Color.FromArgb(255, 0, 110);
    static readonly Color GREEN   = Color.FromArgb(0, 255, 135);
    static readonly Color DIMTXT  = Color.FromArgb(70, 90, 130);

    System.Windows.Forms.Timer _timer;
    int _progress = 0;
    float _hexOff = 0;
    string _status = "Initializing secure environment...";

    static readonly string[] MSGS = {
        "Initializing cryptographic engine...",
        "Loading AES-256 cipher module...",
        "Loading DES / 3DES module...",
        "Loading RC2 cipher module...",
        "Verifying entropy source...",
        "Establishing secure workspace...",
        "Ready."
    };

    public SplashScreen()
    {
        FormBorderStyle = FormBorderStyle.None;
        Size            = new Size(640, 370);
        BackColor       = BG;
        StartPosition   = FormStartPosition.CenterScreen;
        DoubleBuffered  = true;

        _timer          = new System.Windows.Forms.Timer { Interval = 40 };
        _timer.Tick    += (s, e) =>
        {
            _hexOff += 0.4f;
            _progress = Math.Min(_progress + 2, 100);
            _status   = MSGS[Math.Min(_progress / 15, MSGS.Length - 1)];
            Invalidate();
            if (_progress >= 100)
            {
                _timer.Stop();
                Thread.Sleep(300);
                Hide();
                new MainForm().ShowDialog();
                Close();
            }
        };
        _timer.Start();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode     = SmoothingMode.AntiAlias;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        // Hex grid
        using (var p = new Pen(Color.FromArgb(18, 0, 212, 255), 0.8f))
        {
            float r = 22f, dx = r * 1.732f, dy = r * 1.5f;
            for (float row = -1; row < Height / dy + 2; row++)
                for (float col = -1; col < Width / dx + 2; col++)
                    DrawHex(g, p, col * dx + (row % 2 == 0 ? 0 : dx / 2) + (_hexOff % dx) - dx, row * dy, r);
        }

        // Card
        var card = new Rectangle(60, 40, Width - 120, Height - 100);
        using (var br = new SolidBrush(Color.FromArgb(200, 16, 20, 32))) g.FillRectangle(br, card);
        using (var p = new Pen(Color.FromArgb(60, 0, 212, 255), 1))      g.DrawRectangle(p, card);
        using (var p = new Pen(CYAN, 2))    g.DrawLine(p, card.Left, card.Top, card.Left + 100, card.Top);
        using (var p = new Pen(MAGENTA, 2)) g.DrawLine(p, card.Right - 100, card.Top, card.Right, card.Top);

        // Icon
        DrawHexIcon(g, new PointF(Width / 2f, 110), 26);

        // Title
        using (var f = new Font("Consolas", 26f, FontStyle.Bold))
        using (var br = new SolidBrush(CYAN))
        {
            var sz = g.MeasureString("CIPHERFORGE", f);
            g.DrawString("CIPHERFORGE", f, br, (Width - sz.Width) / 2, 140);
        }

        // Subtitle
        using (var f = new Font("Consolas", 8.5f))
        using (var br = new SolidBrush(DIMTXT))
        {
            var sub = "ADVANCED ENCRYPTION WORKSTATION  //  v2.1";
            var sz  = g.MeasureString(sub, f);
            g.DrawString(sub, f, br, (Width - sz.Width) / 2, 182);
        }

        // Progress bar
        int bx = 100, by2 = 228, bw = Width - 200, bh = 4;
        using (var br = new SolidBrush(Color.FromArgb(25, 0, 212, 255))) g.FillRectangle(br, bx, by2, bw, bh);
        int fillW = (int)(bw * (_progress / 100.0));
        if (fillW > 0)
        {
            using (var br = new LinearGradientBrush(new Rectangle(bx, by2, bw, bh), MAGENTA, CYAN, LinearGradientMode.Horizontal))
                g.FillRectangle(br, bx, by2, fillW, bh);
            using (var br = new SolidBrush(Color.FromArgb(130, CYAN)))
                g.FillEllipse(br, bx + fillW - 6, by2 - 3, 10, 10);
        }

        // Status
        using (var f = new Font("Consolas", 8f))
        using (var br = new SolidBrush(Color.FromArgb(160, 0, 212, 255)))
        {
            var sz = g.MeasureString(_status, f);
            g.DrawString(_status, f, br, (Width - sz.Width) / 2, by2 + 12);
        }

        // Percent
        using (var f = new Font("Consolas", 7.5f))
        using (var br = new SolidBrush(DIMTXT))
            g.DrawString($"{_progress}%", f, br, bx + bw + 8, by2 - 1);

        // Author
        using (var f = new Font("Consolas", 8f))
        using (var br = new SolidBrush(Color.FromArgb(90, 0, 200, 100)))
        {
            var auth = "Made by Krut Vyas";
            var sz   = g.MeasureString(auth, f);
            g.DrawString(auth, f, br, (Width - sz.Width) / 2, Height - 60);
        }
    }

    void DrawHexIcon(Graphics g, PointF c, float r)
    {
        using (var p = new Pen(Color.FromArgb(120, 0, 212, 255), 1.5f))
        {
            var pts = new PointF[6];
            for (int i = 0; i < 6; i++) { double a = Math.PI / 180 * (60 * i - 30); pts[i] = new PointF(c.X + r * (float)Math.Cos(a), c.Y + r * (float)Math.Sin(a)); }
            g.DrawPolygon(p, pts);
        }
        using (var br = new SolidBrush(CYAN)) g.FillEllipse(br, c.X - 4, c.Y - 4, 8, 8);
    }

    void DrawHex(Graphics g, Pen p, float cx, float cy, float r)
    {
        var pts = new PointF[6];
        for (int i = 0; i < 6; i++) { double a = Math.PI / 180 * (60 * i - 30); pts[i] = new PointF(cx + r * (float)Math.Cos(a), cy + r * (float)Math.Sin(a)); }
        g.DrawPolygon(p, pts);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  MAIN FORM
// ════════════════════════════════════════════════════════════════════════════
class MainForm : Form
{
    // Palette
    static readonly Color BG_DEEP   = Color.FromArgb(10, 13, 20);
    static readonly Color BG_CARD   = Color.FromArgb(16, 20, 32);
    static readonly Color BG_INPUT  = Color.FromArgb(20, 26, 42);
    static readonly Color CYAN      = Color.FromArgb(0, 212, 255);
    static readonly Color MAGENTA   = Color.FromArgb(255, 0, 110);
    static readonly Color GREEN     = Color.FromArgb(0, 255, 135);
    static readonly Color TXT_MAIN  = Color.FromArgb(220, 230, 255);
    static readonly Color TXT_DIM   = Color.FromArgb(80, 100, 140);

    // Fonts
    Font fTitle, fSub, fMono11, fMono9, fAuthor;

    // Text tab controls
    RichTextBox txtIn, txtOut;
    ComboBox    cmbAlgo;
    TextBox     txtKey, txtIV;
    Label       lblStatus;

    // File tab controls
    TextBox   txtFilePath, txtFKey, txtFIV;
    ComboBox  cmbFAlgo;
    RichTextBox txtLog;
    Label       lblFStatus;

    public MainForm()
    {
        fTitle  = new Font("Consolas", 20f, FontStyle.Bold);
        fSub    = new Font("Consolas", 8.5f);
        fMono11 = new Font("Consolas", 11f);
        fMono9  = new Font("Consolas", 9f);
        fAuthor = new Font("Consolas", 8f);

        Text            = "CipherForge v2.1 — Advanced Encryption Workstation";
        Size            = new Size(1020, 800);
        MinimumSize     = new Size(900, 700);
        BackColor       = BG_DEEP;
        ForeColor       = TXT_MAIN;
        StartPosition   = FormStartPosition.CenterScreen;
        DoubleBuffered  = true;
        Font            = fMono11;

        BuildHeader();
        BuildTabs();
        BuildFooter();
    }

    // ── HEADER ────────────────────────────────────────────────────────────
    void BuildHeader()
    {
        var hdr = new Panel { Dock = DockStyle.Top, Height = 88, BackColor = BG_CARD };
        hdr.Paint += (s, e) =>
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (var p = new Pen(Color.FromArgb(40, 0, 212, 255), 1))  g.DrawLine(p, 0, hdr.Height - 1, hdr.Width, hdr.Height - 1);
            using (var p = new Pen(Color.FromArgb(15, 0, 212, 255), 3))  g.DrawLine(p, 0, hdr.Height - 3, hdr.Width, hdr.Height - 3);
            // Hex decoration
            using (var p = new Pen(Color.FromArgb(14, 0, 212, 255), 0.8f))
            {
                float r = 16f, dx = r * 1.732f, dy = r * 1.5f;
                for (float row = -1; row < hdr.Height / dy + 2; row++)
                    for (float col = -1; col < hdr.Width / dx + 2; col++)
                        DrawHex(g, p, col * dx + (row % 2 == 0 ? 0 : dx / 2), row * dy, r);
            }
        };

        Lbl(hdr, "⬡  CIPHERFORGE",                          new Point(20, 12), CYAN,    fTitle);
        Lbl(hdr, "ADVANCED ENCRYPTION WORKSTATION  //  AES · DES · TripleDES · RC2",
                                                              new Point(22, 50), TXT_DIM, fSub);
        var auth = Lbl(hdr, "◈  DESIGNED & ENGINEERED BY  KRUT VYAS", new Point(0, 30), Color.FromArgb(0, 200, 100), fAuthor);
        auth.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        auth.Location = new Point(hdr.Width - auth.PreferredWidth - 18, 30);
        var sec  = Lbl(hdr, "● SECURE", new Point(0, 52), GREEN, fSub);
        sec.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        sec.Location = new Point(hdr.Width - sec.PreferredWidth - 18, 52);

        Controls.Add(hdr);
    }

    // ── FOOTER ────────────────────────────────────────────────────────────
    void BuildFooter()
    {
        var ftr = new Panel { Dock = DockStyle.Bottom, Height = 28, BackColor = BG_CARD };
        ftr.Paint += (s, e) => { using (var p = new Pen(Color.FromArgb(30, 0, 212, 255), 1)) e.Graphics.DrawLine(p, 0, 0, ftr.Width, 0); };
        Lbl(ftr, "CipherForge v2.1  //  Made by Krut Vyas  //  © 2025  //  AES-256 · DES · 3DES · RC2",
            new Point(0, 0), TXT_DIM, fAuthor).Dock = DockStyle.Fill;
        ((Label)ftr.Controls[0]).TextAlign = ContentAlignment.MiddleCenter;
        Controls.Add(ftr);
    }

    // ── TABS ──────────────────────────────────────────────────────────────
    void BuildTabs()
    {
        var tc = new TabControl
        {
            Dock     = DockStyle.Fill,
            DrawMode = TabDrawMode.OwnerDrawFixed,
            SizeMode = TabSizeMode.Fixed,
            ItemSize = new Size(160, 38),
            BackColor = BG_DEEP,
            Font = fMono11,
            Padding = new Point(16, 6)
        };
        tc.DrawItem += (s, e) =>
        {
            bool sel = e.Index == tc.SelectedIndex;
            var  r   = tc.GetTabRect(e.Index);
            e.Graphics.FillRectangle(new SolidBrush(sel ? BG_CARD : BG_DEEP), r);
            if (sel) e.Graphics.DrawLine(new Pen(CYAN, 2), r.Left, r.Top, r.Right, r.Top);
            e.Graphics.DrawString(tc.TabPages[e.Index].Text, fMono11, new SolidBrush(sel ? CYAN : TXT_DIM),
                r, new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center });
        };
        tc.SelectedIndexChanged += (s, e) => tc.Invalidate();

        var pgText = new TabPage("  ◈  TEXT  ") { BackColor = BG_DEEP };
        var pgFile = new TabPage("  ◈  FILE  ") { BackColor = BG_DEEP };
        tc.TabPages.AddRange(new[] { pgText, pgFile });

        BuildTextTab(pgText);
        BuildFileTab(pgFile);

        var wrap = new Panel { Dock = DockStyle.Fill, BackColor = BG_DEEP, Padding = new Padding(10, 8, 10, 0) };
        wrap.Controls.Add(tc);
        Controls.Add(wrap);
    }

    // ── TEXT TAB ──────────────────────────────────────────────────────────
    void BuildTextTab(TabPage pg)
    {
        pg.Padding = new Padding(10);

        // Config card
        var card = Card(pg, new Point(0, 0), new Size(pg.Width - 20, 116));
        card.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        Lbl(card, "ALGORITHM",  new Point(10, 10), CYAN, fSub);
        cmbAlgo = Combo(card, new Point(10, 28), 190, new[] { "AES-256", "DES", "TripleDES", "RC2" });

        Lbl(card, "ENCRYPTION KEY  (hex or plaintext)", new Point(216, 10), CYAN, fSub);
        txtKey = Input(card, new Point(216, 28), 420);
        txtKey.Text = HexKey(32);

        Lbl(card, "IV  (optional)", new Point(652, 10), CYAN, fSub);
        txtIV = Input(card, new Point(652, 28), 220);
        txtIV.Text = HexKey(16);

        Btn(card, "↻ GEN KEY", new Point(216, 72), 120, CYAN).Click  += (s, e) => txtKey.Text = HexKey(KeySize(cmbAlgo.Text));
        Btn(card, "↻ GEN IV",  new Point(346, 72), 120, CYAN).Click  += (s, e) => txtIV.Text  = HexKey(16);

        // Input
        int y = 128;
        Lbl(pg, "◤  INPUT PLAINTEXT / CIPHERTEXT", new Point(0, y), TXT_DIM, fSub);
        txtIn = new RichTextBox { Location = new Point(0, y + 18), Size = new Size(pg.Width - 20, 155),
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
            BackColor = BG_INPUT, ForeColor = TXT_MAIN, BorderStyle = BorderStyle.None, Font = fMono11 };
        pg.Controls.Add(txtIn);

        // Buttons
        int by = y + 165;
        Btn(pg, "⬡  ENCRYPT",    new Point(0,   by), 170, CYAN).Click    += (s, e) => DoText(true);
        Btn(pg, "⬡  DECRYPT",    new Point(180, by), 170, MAGENTA).Click += (s, e) => DoText(false);
        Btn(pg, "✕  CLEAR",      new Point(360, by), 150, TXT_DIM).Click += (s, e) => { txtIn.Clear(); txtOut.Clear(); SetStatus("Cleared.", CYAN); };
        Btn(pg, "⎘  COPY OUTPUT",new Point(520, by), 180, GREEN).Click   += (s, e) =>
        {
            if (!string.IsNullOrEmpty(txtOut.Text)) { Clipboard.SetText(txtOut.Text); SetStatus("Copied to clipboard.", GREEN); }
        };

        lblStatus = new Label { Text = "[ READY ]  Choose algorithm, set key and press ENCRYPT or DECRYPT.",
            Font = fSub, ForeColor = TXT_DIM, Location = new Point(0, by + 44),
            AutoSize = false, Height = 20, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
        pg.Controls.Add(lblStatus);

        // Output
        int oy = by + 70;
        Lbl(pg, "◤  OUTPUT CIPHERTEXT / PLAINTEXT", new Point(0, oy), TXT_DIM, fSub);
        txtOut = new RichTextBox { Location = new Point(0, oy + 18), Size = new Size(pg.Width - 20, 155),
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
            BackColor = BG_INPUT, ForeColor = GREEN, BorderStyle = BorderStyle.None, Font = fMono11, ReadOnly = true };
        pg.Controls.Add(txtOut);

        pg.Resize += (s, e) =>
        {
            int w = pg.ClientSize.Width - 20;
            card.Width = w; txtIn.Width = w; txtOut.Width = w; lblStatus.Width = w;
        };
    }

    // ── FILE TAB ──────────────────────────────────────────────────────────
    void BuildFileTab(TabPage pg)
    {
        pg.Padding = new Padding(10);

        var card = Card(pg, new Point(0, 0), new Size(pg.Width - 20, 180));
        card.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

        Lbl(card, "TARGET FILE", new Point(10, 10), CYAN, fSub);
        txtFilePath = Input(card, new Point(10, 28), 500);
        txtFilePath.PlaceholderText = "Select a file to encrypt or decrypt...";
        Btn(card, "◈ BROWSE", new Point(520, 28), 140, CYAN).Click += (s, e) =>
        {
            using var d = new OpenFileDialog { Filter = "All Files (*.*)|*.*" };
            if (d.ShowDialog() == DialogResult.OK) txtFilePath.Text = d.FileName;
        };

        Lbl(card, "ALGORITHM", new Point(10, 76), CYAN, fSub);
        cmbFAlgo = Combo(card, new Point(10, 94), 180, new[] { "AES-256", "DES", "TripleDES", "RC2" });

        Lbl(card, "ENCRYPTION KEY", new Point(206, 76), CYAN, fSub);
        txtFKey = Input(card, new Point(206, 94), 380);
        txtFKey.Text = HexKey(32);

        Lbl(card, "IV", new Point(600, 76), CYAN, fSub);
        txtFIV = Input(card, new Point(600, 94), 220);
        txtFIV.Text = HexKey(16);

        Btn(card, "↻ KEY", new Point(206, 138), 100, CYAN).Click += (s, e) => txtFKey.Text = HexKey(KeySize(cmbFAlgo.Text));
        Btn(card, "↻ IV",  new Point(316, 138), 100, CYAN).Click += (s, e) => txtFIV.Text  = HexKey(16);

        Btn(pg, "⬡  ENCRYPT FILE", new Point(0,   192), 210, CYAN).Click    += (s, e) => DoFile(true);
        Btn(pg, "⬡  DECRYPT FILE", new Point(220, 192), 210, MAGENTA).Click += (s, e) => DoFile(false);

        lblFStatus = new Label { Text = "[ READY ]  Browse a file then ENCRYPT or DECRYPT.",
            Font = fSub, ForeColor = TXT_DIM, Location = new Point(0, 238),
            AutoSize = false, Height = 20, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
        pg.Controls.Add(lblFStatus);

        Lbl(pg, "◤  OPERATION LOG", new Point(0, 264), TXT_DIM, fSub);
        txtLog = new RichTextBox { Location = new Point(0, 282),
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom,
            BackColor = BG_INPUT, ForeColor = TXT_DIM, BorderStyle = BorderStyle.None, Font = fMono9, ReadOnly = true };
        pg.Controls.Add(txtLog);

        Log("CipherForge File Engine ready.");
        Log("Output files saved next to source with .enc / .dec extension.");

        pg.Resize += (s, e) =>
        {
            int w = pg.ClientSize.Width - 20;
            card.Width = w; lblFStatus.Width = w;
            txtLog.Width = w; txtLog.Height = pg.ClientSize.Height - 290;
        };
    }

    // ══════════════════════════════════════════════════════════════════════
    //  CRYPTO LOGIC
    // ══════════════════════════════════════════════════════════════════════
    void DoText(bool encrypt)
    {
        if (string.IsNullOrWhiteSpace(txtIn.Text)) { SetStatus("ERROR: Input is empty.", MAGENTA); return; }
        try
        {
            if (encrypt)
            {
                var enc = Transform(Encoding.UTF8.GetBytes(txtIn.Text), true, cmbAlgo.Text, txtKey.Text, txtIV.Text);
                txtOut.Text = Convert.ToBase64String(enc);
                SetStatus($"ENCRYPTED ✓  {txtIn.Text.Length} chars  //  {cmbAlgo.Text}", GREEN);
            }
            else
            {
                var dec = Transform(Convert.FromBase64String(txtIn.Text.Trim()), false, cmbAlgo.Text, txtKey.Text, txtIV.Text);
                txtOut.Text = Encoding.UTF8.GetString(dec);
                SetStatus($"DECRYPTED ✓  {dec.Length} bytes  //  {cmbAlgo.Text}", GREEN);
            }
        }
        catch (Exception ex) { SetStatus("ERROR: " + ex.Message, MAGENTA); }
    }

    void DoFile(bool encrypt)
    {
        if (string.IsNullOrWhiteSpace(txtFilePath.Text) || !File.Exists(txtFilePath.Text))
        { Log("ERROR: No valid file selected."); FStatus("ERROR: Select a valid file.", MAGENTA); return; }
        try
        {
            string src = txtFilePath.Text;
            string dst = encrypt ? src + ".enc" : (src.EndsWith(".enc") ? src.Replace(".enc", ".dec") : src + ".dec");
            byte[] data = File.ReadAllBytes(src);
            Log($"Reading: {Path.GetFileName(src)}  ({data.Length:N0} bytes)");
            byte[] result = Transform(data, encrypt, cmbFAlgo.Text, txtFKey.Text, txtFIV.Text);
            File.WriteAllBytes(dst, result);
            Log($"{(encrypt ? "ENCRYPTED" : "DECRYPTED")} ✓  Saved: {Path.GetFileName(dst)}  ({result.Length:N0} bytes)");
            FStatus($"{(encrypt ? "ENCRYPTED" : "DECRYPTED")} ✓  → {Path.GetFileName(dst)}", GREEN);
        }
        catch (Exception ex) { Log("ERROR: " + ex.Message); FStatus("ERROR: " + ex.Message, MAGENTA); }
    }

    byte[] Transform(byte[] data, bool enc, string algo, string keyStr, string ivStr)
    {
        using SymmetricAlgorithm sa = algo switch
        {
            "DES"       => DES.Create(),
            "TripleDES" => TripleDES.Create(),
            "RC2"       => RC2.Create(),
            _           => Aes.Create()
        };
        sa.Key     = PadBytes(ParseKey(keyStr), BestKeySize(sa));
        sa.IV      = PadBytes(ParseKey(ivStr),  sa.BlockSize / 8);
        sa.Padding = PaddingMode.PKCS7;
        sa.Mode    = CipherMode.CBC;
        using var ms = new MemoryStream();
        using (var cs = new CryptoStream(ms, enc ? sa.CreateEncryptor() : sa.CreateDecryptor(), CryptoStreamMode.Write))
        { cs.Write(data, 0, data.Length); cs.FlushFinalBlock(); }
        return ms.ToArray();
    }

    static byte[] ParseKey(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return new byte[16];
        if (Regex.IsMatch(s, "^[0-9a-fA-F]+$") && s.Length % 2 == 0)
        {
            var b = new byte[s.Length / 2];
            for (int i = 0; i < b.Length; i++) b[i] = Convert.ToByte(s.Substring(i * 2, 2), 16);
            return b;
        }
        return Encoding.UTF8.GetBytes(s);
    }

    static int BestKeySize(SymmetricAlgorithm sa)
    {
        int best = sa.LegalKeySizes[0].MinSize / 8;
        foreach (var ks in sa.LegalKeySizes)
            for (int sz = ks.MinSize; sz <= ks.MaxSize; sz += Math.Max(ks.SkipSize, 1))
                if (sz / 8 > best) best = sz / 8;
        return best;
    }

    static byte[] PadBytes(byte[] src, int len) { var b = new byte[len]; Array.Copy(src, b, Math.Min(src.Length, len)); return b; }
    static string HexKey(int n) { var b = new byte[n]; RandomNumberGenerator.Fill(b); return BitConverter.ToString(b).Replace("-", "").ToLower(); }
    static int KeySize(string algo) => algo switch { "DES" => 8, "TripleDES" => 24, "RC2" => 16, _ => 32 };

    // ══════════════════════════════════════════════════════════════════════
    //  UI HELPERS
    // ══════════════════════════════════════════════════════════════════════
    Panel Card(Control p, Point loc, Size sz)
    {
        var c = new Panel { Location = loc, Size = sz, BackColor = BG_CARD };
        c.Paint += (s, e) =>
        {
            using (var pen = new Pen(Color.FromArgb(50, 0, 212, 255), 1)) e.Graphics.DrawRectangle(pen, 0, 0, c.Width - 1, c.Height - 1);
            using (var pen = new Pen(CYAN, 2)) e.Graphics.DrawLine(pen, 0, 0, 80, 0);
        };
        p.Controls.Add(c); return c;
    }

    Label Lbl(Control p, string t, Point loc, Color col, Font f = null)
    {
        var l = new Label { Text = t, Location = loc, AutoSize = true, ForeColor = col, BackColor = Color.Transparent, Font = f ?? fSub };
        p.Controls.Add(l); return l;
    }

    TextBox Input(Control p, Point loc, int w)
    {
        var tb = new TextBox { Location = loc, Width = w, Height = 30, BackColor = BG_INPUT, ForeColor = TXT_MAIN, BorderStyle = BorderStyle.FixedSingle, Font = fMono9 };
        p.Controls.Add(tb); return tb;
    }

    ComboBox Combo(Control p, Point loc, int w, string[] items)
    {
        var cb = new ComboBox { Location = loc, Width = w, BackColor = BG_INPUT, ForeColor = CYAN, FlatStyle = FlatStyle.Flat, DropDownStyle = ComboBoxStyle.DropDownList, Font = fMono11 };
        cb.Items.AddRange(items); cb.SelectedIndex = 0;
        p.Controls.Add(cb); return cb;
    }

    Button Btn(Control p, string t, Point loc, int w, Color col)
    {
        var b = new Button
        {
            Text = t, Location = loc, Width = w, Height = 34,
            FlatStyle = FlatStyle.Flat, Font = fSub,
            BackColor = BG_CARD, ForeColor = col, Cursor = Cursors.Hand
        };
        b.FlatAppearance.BorderColor        = col;
        b.FlatAppearance.BorderSize         = 1;
        b.FlatAppearance.MouseOverBackColor = Color.FromArgb(22, col.R, col.G, col.B);
        b.FlatAppearance.MouseDownBackColor = Color.FromArgb(44, col.R, col.G, col.B);
        p.Controls.Add(b); return b;
    }

    void SetStatus(string msg, Color c) { lblStatus.Text = $"[ {DateTime.Now:HH:mm:ss} ]  {msg}"; lblStatus.ForeColor = c; }
    void FStatus(string msg, Color c)   { lblFStatus.Text = $"[ {DateTime.Now:HH:mm:ss} ]  {msg}"; lblFStatus.ForeColor = c; }
    void Log(string line)               { txtLog.AppendText($"[{DateTime.Now:HH:mm:ss}]  {line}\n"); txtLog.ScrollToCaret(); }

    void DrawHex(Graphics g, Pen p, float cx, float cy, float r)
    {
        var pts = new PointF[6];
        for (int i = 0; i < 6; i++) { double a = Math.PI / 180 * (60 * i - 30); pts[i] = new PointF(cx + r * (float)Math.Cos(a), cy + r * (float)Math.Sin(a)); }
        g.DrawPolygon(p, pts);
    }

    protected override void Dispose(bool d) { if (d) { fTitle?.Dispose(); fSub?.Dispose(); fMono11?.Dispose(); fMono9?.Dispose(); fAuthor?.Dispose(); } base.Dispose(d); }
}
